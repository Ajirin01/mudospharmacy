<section id="slider"><!--slider-->
    {{-- <div class="container slider-body"> --}}
                {{-- <div id="slider-carousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
                        <li data-target="#slider-carousel" data-slide-to="1"></li>
                        <li data-target="#slider-carousel" data-slide-to="2"></li>
                    </ol>

                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-sm-8">
                                <img src="{{asset('fontend/images/home/joe.jpg')}}"    class="girl img-responsive" alt="" />
                                <img src="{{asset('fontend/images/home/pricing.')}}"  class="pricing" alt="" />
                            </div>
                        </div>
                        <div class="item">

                            <div class="col-sm-8">
                                <img src="{{asset('fontend/images/home/danger.jpg')}}" class="girl img-responsive" alt="" />
                                <img src="{{asset('fontend/images/home/')}}"  class="pricing" alt="" />
                            </div>
                        </div>


                        <div class="item">

                            <div class="col-sm-8">
                                <img src="{{asset('fontend/images/home/slider1.jpg')}}" class="girl img-responsive" alt="" />
                                <img src="{{asset('fontend/images/home/')}}"  class="pricing" alt="" />
                            </div>
                        </div>


                        <div class="item">

                            <div class="col-sm-8">
                                <img src="{{asset('fontend/images/home/slider2.jpg')}}" class="girl img-responsive" alt="" />
                                <img src="{{asset('fontend/images/home/')}}"  class="pricing" alt="" />
                            </div>
                        </div>




                        <div class="item">

                            <div class="col-sm-8">
                                <img src="{{asset('fontend/images/home/ol.jpg')}}" class="girl img-responsive" alt="" />
                                <img src="{{asset('fontend/images/home/')}}" class="pricing" alt="" />
                            </div>
                        </div>

                    </div>

                    <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>

            </div>
        </div> --}}

        <div class="img-area">
            <div class="img-slide">
                <div class="single-img slick-active" slidesToShow='3'>
                    <img style="width: inherit; height: 300px" src="{{asset('fontend/images/home/mudos_big_logo.jpg')}}" alt="">
                    <h2 class="slick-active">Mudospharmacy</h2>
                    <h5 class="slick-active">Nigeria's largest online <br> Drugstore and medical equipments</h5>
                </div>
                <div class="single-img slick-active">
                    <img style="width: inherit; height: 300px" src="{{asset('fontend/images/home/slider2.jpg')}}" alt="">
                    <h2 class="slick-active">Easy Ordering</h2>
                    <h5 class="slick-active">Order for your drugs <br> in convenience</h5>
                </div>
                <div class="single-img slick-active">
                    <img style="width: inherit; height: 300px" src="{{asset('fontend/images/home/slider1.jpg')}}" alt="">
                    {{-- <h2>test</h2> --}}
                </div>
                <div class="single-img slick-active">
                    <img style="width: inherit; height: 300px" src="{{asset('fontend/images/home/payment-card.jpeg')}}" alt="">
                    <h2 class="slick-active">Easy Payment</h2>
                    <h5 class="slick-active">pay for your items easily</h5>
                </div>
            </div>
        </div>
</section><!--/slider-->
