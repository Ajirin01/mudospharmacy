<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>confirm</title>
    <style>
        .form-group{
            width: 300px; 
            background-color: rgb(10, 1, 12)
        }
        .form-control{
            width: 100%; 
            padding: 10px 0;
            margin: 0 auto;
            background-color: rgb(83, 250, 6);
            border-radius: 50px;
            color:rgb(10, 1, 12);
            /* text-align: center; */
            border: none;
            margin-bottom: 50px
        }
        h2{
            color: white;
            text-align: center;
            padding: 20% 0 30% 0;
        }
        span{
            color: red
        }
    </style>
</head>
<body>
    <div>
        <p>reply_to: hhoollaaggookkee@gmail.com</p>
        <form action="{{$data['host']}}/pharm-confirm-prescription-user" class="form" method="POST">
            <div class="form-group">
                <h2>Congratulation! prescription to your order has been confirmed <br>
                    Please click the button below to proceed <br>
                    <span> Note: use your phone brower to view this message <br>
                    to be able to click the button
                    </span>
                </h2>
                <input type="hidden" name="item_id" value="{{$data['item_id']}}">
                <input type="hidden" name="prescription" value="{{$data['prescription']}}">
                <input class="form-control" type="submit" value="continue">
            </div>
        </form>
    </div>
</body>
</html>
