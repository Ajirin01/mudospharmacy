<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>confirm</title>
    <style>
        .form-group{
            width: 300px; 
            background-color: rgb(10, 1, 12)
        }
        .form-control{
            width: 100%; 
            padding: 10px 0;
            margin: 0 auto;
            background-color: rgb(83, 250, 6);
            border-radius: 50px;
            color:rgb(10, 1, 12);
            /* text-align: center; */
            border: none;
            margin-bottom: 50px
        }
        h2{
            color: white;
            text-align: center;
            padding: 20% 0 30% 0;
        }
        
    </style>
</head>
<body>
    <div>
        <p>reply_to: {{$data['email']}}</p>
                <form action="{{$data['host']}}/pharm-confirm-prescription" class="form" method="POST">
                    <div class="form-group">
                        <h2>Please confirm prescription validity</h2>
                        <input type="hidden" name="email" value="{{$data['email']}}">
                        <input type="hidden" name="item_id" value="{{$data['item_id']}}">
                        <input type="hidden" name="prescription" value="{{$data['prescription']}}">
                        <input class="form-control" type="submit" value="confirm">
                    </div>
                </form>
                
</body>
</html>
